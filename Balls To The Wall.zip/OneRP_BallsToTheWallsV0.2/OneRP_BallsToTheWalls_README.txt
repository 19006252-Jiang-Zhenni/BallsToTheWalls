Balls to the Walls is a puzzle platformer where you fling/slingshot a bouncy
ball onto walls. The catch, you must hit a wall to fling again. Plan your
route carefully to complete each level.

Each level contains 3 optional stars. You don't have to collect any to win.
But they're great for bragging rights!

Note: All levels in our game are currently unlocked. Please play them in
sequence as if each level is only accessible after completing the previous
one. However if a level proves to be too difficult, you may skip it.

Please take a moment to fill up our playtest feedback form after you have
completed the game! Thank you! https://forms.gle/ho6kG3HdG6o9SJ4A6
---------------------------------------------------------------------------------------------------------
Class: CSD1401F22-B
Team:  OneRP
Members:
Seetoh Wei Tung	seetoh.w@digipen.edu
Liang HongJie	l.hongjie@digipen.edu
Jiang Zhenni	j.zhenni@digipen.edu
Yeo Jun Jie	junjie.yeo@digipen.edu
---------------------------------------------------------------------------------------------------------

Controls: (All controls are explained during gameplay)

Left-click and drag anywhere to aim. (Time slows down during aiming)
Release left mouse button to fling.

Keyboard Tips/Shortcuts (also shown in-game): 
Press [Esc] to pause.
Press [R] in game or in level complete screen to restart the level.
Press [Space] to switch between slingshot/throw mode.
Click anywhere during level complete screen to speed up the animations.